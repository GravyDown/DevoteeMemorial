import { Toaster } from "@/components/ui/sonner";
import { VlyToolbar } from "../vly-toolbar-readonly.tsx";
import { InstrumentationProvider } from "@/instrumentation.tsx";
import { StrictMode, useEffect, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes, useLocation } from "react-router";
import "./index.css";
import "./types/global.d.ts";
import DiscipleDetail from "./pages/DiscipleDetail.tsx";
import ProtectedRoute from "./components/ProtectedRoute.tsx";
const AdminDashboard = lazy(() => import("./pages/AdminDashboard.tsx"));
const Disciples = lazy(() => import("./pages/Disciples.tsx"));
const Quotes = lazy(() => import("./pages/Quotes.tsx"));
const About = lazy(() => import("./pages/About.tsx"));
const Contact = lazy(() => import("./pages/Contact.tsx"));
const ForgotPassword = lazy(() => import("./components/ForgotPassword.tsx"));
const ResetPassword = lazy(() => import("./components/ResetPassword.tsx"));

// Lazy load route components for better code splitting
const Home = lazy(() => import("./pages/Home.tsx"));
const AuthPage = lazy(() => import("./pages/Auth.tsx"));
const CreateMemorial = lazy(() => import("./pages/CreateMemorial.tsx"));
const CreateOffering = lazy(() => import("./pages/CreateOffering.tsx"));
const NotFound = lazy(() => import("./pages/NotFound.tsx"));
const Register = lazy(() => import("./pages/Register.tsx"));

// Simple loading fallback for route transitions
function RouteLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-pulse text-muted-foreground">Loading...</div>
    </div>
  );
}

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function RouteSyncer() {
  const location = useLocation();
  useEffect(() => {
    window.parent.postMessage(
      { type: "iframe-route-change", path: location.pathname },
      "*",
    );
  }, [location.pathname]);

  useEffect(() => {
    function handleMessage(event: MessageEvent) {
      if (event.data?.type === "navigate") {
        if (event.data.direction === "back") window.history.back();
        if (event.data.direction === "forward") window.history.forward();
      }
    }
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  return null;
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <VlyToolbar />
    <InstrumentationProvider>
      <BrowserRouter>
        <ScrollToTop />
        <RouteSyncer />
        <Suspense fallback={<RouteLoading />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/register" element={<Register />} />
            <Route
              path="/auth"
              element={<AuthPage redirectAfterAuth="/" />}
            />{" "}
            {/* TODO: change redirect after auth to correct page */}
            <Route
              path="/create-memorial"
              element={
                <ProtectedRoute>
                  <CreateMemorial />
                </ProtectedRoute>
              }
            />
            <Route path="/offerings/new" element={<CreateOffering />} />
            <Route path="/disciples/:id" element={<DiscipleDetail />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/disciples" element={<Disciples />} />
            <Route path="/quotes" element={<Quotes />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
      <Toaster />
    </InstrumentationProvider>
  </StrictMode>,
);
